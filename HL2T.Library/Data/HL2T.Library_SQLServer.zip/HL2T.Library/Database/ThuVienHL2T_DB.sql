/* =====================================================================
   HỆ THỐNG QUẢN LÝ SÁCH THƯ VIỆN HL2T
   Script tạo cơ sở dữ liệu ThuVienHL2T_DB – Microsoft SQL Server 2014+
   Chạy bằng SQL Server Management Studio (SSMS) hoặc Azure Data Studio.
   ===================================================================== */
USE master;
GO
IF DB_ID(N'ThuVienHL2T_DB') IS NOT NULL
BEGIN
    ALTER DATABASE ThuVienHL2T_DB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ThuVienHL2T_DB;
END
GO
CREATE DATABASE ThuVienHL2T_DB COLLATE Vietnamese_CI_AS;
GO
USE ThuVienHL2T_DB;
GO

/* ---------------------------------------------------------------------
   1. VaiTro
   --------------------------------------------------------------------- */
CREATE TABLE dbo.VaiTro (
    MaVaiTro   INT IDENTITY(1,1) NOT NULL,
    TenVaiTro  NVARCHAR(50)  NOT NULL,
    MoTa       NVARCHAR(255) NULL,
    CONSTRAINT PK_VaiTro PRIMARY KEY (MaVaiTro),
    CONSTRAINT UQ_VaiTro_Ten UNIQUE (TenVaiTro)
);
GO

/* ---------------------------------------------------------------------
   2. NguoiDung
   --------------------------------------------------------------------- */
CREATE TABLE dbo.NguoiDung (
    MaNguoiDung  INT IDENTITY(1,1) NOT NULL,
    TenDangNhap  NVARCHAR(50)  NOT NULL,
    MatKhauHash  NVARCHAR(255) NOT NULL,
    HoTen        NVARCHAR(100) NOT NULL,
    Email        NVARCHAR(100) NOT NULL,
    SoDienThoai  NVARCHAR(15)  NULL,
    DiaChi       NVARCHAR(255) NULL,
    NgayTao      DATETIME2     NOT NULL CONSTRAINT DF_NguoiDung_NgayTao DEFAULT (GETDATE()),
    TrangThai    BIT           NOT NULL CONSTRAINT DF_NguoiDung_TrangThai DEFAULT (1),
    MaVaiTro     INT           NOT NULL,
    CONSTRAINT PK_NguoiDung PRIMARY KEY (MaNguoiDung),
    CONSTRAINT UQ_NguoiDung_TenDangNhap UNIQUE (TenDangNhap),
    CONSTRAINT UQ_NguoiDung_Email UNIQUE (Email),
    CONSTRAINT FK_NguoiDung_VaiTro FOREIGN KEY (MaVaiTro) REFERENCES dbo.VaiTro (MaVaiTro)
);
GO

/* ---------------------------------------------------------------------
   3. DanhMucSach
   --------------------------------------------------------------------- */
CREATE TABLE dbo.DanhMucSach (
    MaDanhMuc   INT IDENTITY(1,1) NOT NULL,
    TenDanhMuc  NVARCHAR(100) NOT NULL,
    MoTa        NVARCHAR(255) NULL,
    CONSTRAINT PK_DanhMucSach PRIMARY KEY (MaDanhMuc),
    CONSTRAINT UQ_DanhMucSach_Ten UNIQUE (TenDanhMuc)
);
GO

/* ---------------------------------------------------------------------
   4. Sach
   --------------------------------------------------------------------- */
CREATE TABLE dbo.Sach (
    MaSach          INT IDENTITY(1,1) NOT NULL,
    ISBN            NVARCHAR(20)  NULL,
    TenSach         NVARCHAR(255) NOT NULL,
    TacGia          NVARCHAR(150) NOT NULL,
    NhaXuatBan      NVARCHAR(150) NULL,
    NamXuatBan      INT           NULL,
    GiaBia          DECIMAL(12,0) NOT NULL CONSTRAINT DF_Sach_GiaBia DEFAULT (0),
    AnhBia          NVARCHAR(255) NULL,
    MoTa            NVARCHAR(MAX) NULL,
    TongSoLuong     INT           NOT NULL CONSTRAINT DF_Sach_TongSoLuong DEFAULT (0),
    SoLuongKhaDung  INT           NOT NULL CONSTRAINT DF_Sach_SoLuongKhaDung DEFAULT (0),
    MaDanhMuc       INT           NOT NULL,
    CONSTRAINT PK_Sach PRIMARY KEY (MaSach),
    CONSTRAINT FK_Sach_DanhMucSach FOREIGN KEY (MaDanhMuc) REFERENCES dbo.DanhMucSach (MaDanhMuc),
    CONSTRAINT CK_Sach_TongSoLuong CHECK (TongSoLuong >= 0),
    CONSTRAINT CK_Sach_SoLuongKhaDung CHECK (SoLuongKhaDung >= 0 AND SoLuongKhaDung <= TongSoLuong)
);
GO
-- ISBN duy nhất nhưng cho phép nhiều sách chưa có ISBN (NULL)
CREATE UNIQUE INDEX UX_Sach_ISBN ON dbo.Sach (ISBN) WHERE ISBN IS NOT NULL;
CREATE INDEX IX_Sach_TenSach ON dbo.Sach (TenSach);
CREATE INDEX IX_Sach_TacGia ON dbo.Sach (TacGia);
CREATE INDEX IX_Sach_MaDanhMuc ON dbo.Sach (MaDanhMuc);
GO

/* ---------------------------------------------------------------------
   5. PhieuMuon
   --------------------------------------------------------------------- */
CREATE TABLE dbo.PhieuMuon (
    MaPhieuMuon  INT IDENTITY(1,1) NOT NULL,
    MaDocGia     INT           NOT NULL,
    MaThuThu     INT           NULL,
    NgayLap      DATETIME2     NOT NULL CONSTRAINT DF_PhieuMuon_NgayLap DEFAULT (GETDATE()),
    NgayMuon     DATE          NULL,
    NgayHenTra   DATE          NULL,
    DaGiaHan     BIT           NOT NULL CONSTRAINT DF_PhieuMuon_DaGiaHan DEFAULT (0),
    TrangThai    NVARCHAR(20)  NOT NULL CONSTRAINT DF_PhieuMuon_TrangThai DEFAULT (N'ChoDuyet'),
    GhiChu       NVARCHAR(255) NULL,
    CONSTRAINT PK_PhieuMuon PRIMARY KEY (MaPhieuMuon),
    CONSTRAINT FK_PhieuMuon_DocGia FOREIGN KEY (MaDocGia) REFERENCES dbo.NguoiDung (MaNguoiDung),
    CONSTRAINT FK_PhieuMuon_ThuThu FOREIGN KEY (MaThuThu) REFERENCES dbo.NguoiDung (MaNguoiDung),
    CONSTRAINT CK_PhieuMuon_TrangThai CHECK (TrangThai IN (N'ChoDuyet', N'DangMuon', N'QuaHan', N'DaTra', N'DaHuy'))
);
GO
CREATE INDEX IX_PhieuMuon_TrangThai ON dbo.PhieuMuon (TrangThai);
CREATE INDEX IX_PhieuMuon_MaDocGia ON dbo.PhieuMuon (MaDocGia);
GO

/* ---------------------------------------------------------------------
   6. ChiTietPhieuMuon
   --------------------------------------------------------------------- */
CREATE TABLE dbo.ChiTietPhieuMuon (
    MaChiTiet        INT IDENTITY(1,1) NOT NULL,
    MaPhieuMuon      INT          NOT NULL,
    MaSach           INT          NOT NULL,
    SoLuong          INT          NOT NULL CONSTRAINT DF_CTPM_SoLuong DEFAULT (1),
    NgayTraThucTe    DATE         NULL,
    TinhTrangKhiTra  NVARCHAR(50) NULL,
    CONSTRAINT PK_ChiTietPhieuMuon PRIMARY KEY (MaChiTiet),
    CONSTRAINT FK_CTPM_PhieuMuon FOREIGN KEY (MaPhieuMuon) REFERENCES dbo.PhieuMuon (MaPhieuMuon) ON DELETE CASCADE,
    CONSTRAINT FK_CTPM_Sach FOREIGN KEY (MaSach) REFERENCES dbo.Sach (MaSach),
    CONSTRAINT CK_CTPM_SoLuong CHECK (SoLuong > 0)
);
GO
CREATE INDEX IX_CTPM_MaPhieuMuon ON dbo.ChiTietPhieuMuon (MaPhieuMuon);
CREATE INDEX IX_CTPM_MaSach ON dbo.ChiTietPhieuMuon (MaSach);
GO

/* ---------------------------------------------------------------------
   7. BienLaiPhat
   --------------------------------------------------------------------- */
CREATE TABLE dbo.BienLaiPhat (
    MaBienLai    INT IDENTITY(1,1) NOT NULL,
    MaPhieuMuon  INT           NOT NULL,
    MaDocGia     INT           NOT NULL,
    LyDo         NVARCHAR(255) NOT NULL,
    SoTien       DECIMAL(12,0) NOT NULL,
    NgayLap      DATETIME2     NOT NULL CONSTRAINT DF_BLP_NgayLap DEFAULT (GETDATE()),
    DaThanhToan  BIT           NOT NULL CONSTRAINT DF_BLP_DaThanhToan DEFAULT (0),
    CONSTRAINT PK_BienLaiPhat PRIMARY KEY (MaBienLai),
    CONSTRAINT FK_BLP_PhieuMuon FOREIGN KEY (MaPhieuMuon) REFERENCES dbo.PhieuMuon (MaPhieuMuon),
    CONSTRAINT FK_BLP_DocGia FOREIGN KEY (MaDocGia) REFERENCES dbo.NguoiDung (MaNguoiDung),
    CONSTRAINT CK_BLP_SoTien CHECK (SoTien >= 0)
);
GO
CREATE INDEX IX_BLP_MaDocGia ON dbo.BienLaiPhat (MaDocGia);
GO

/* =====================================================================
   DỮ LIỆU MẪU
   Mật khẩu ghi dạng 'SEED:<mật khẩu>'; khi ứng dụng khởi động lần đầu,
   DbSeeder sẽ tự băm lại bằng BCrypt.
     admin / Admin@123    thuthu / ThuThu@123    docgia / DocGia@123
   ===================================================================== */
INSERT INTO dbo.VaiTro (TenVaiTro, MoTa) VALUES
 (N'Admin',  N'Quản trị viên hệ thống'),
 (N'ThuThu', N'Thủ thư – quản lý kho sách và mượn trả'),
 (N'DocGia', N'Độc giả – tra cứu và mượn sách');

INSERT INTO dbo.NguoiDung (TenDangNhap, MatKhauHash, HoTen, Email, SoDienThoai, DiaChi, MaVaiTro) VALUES
 (N'admin',   N'SEED:Admin@123',  N'Nguyễn Văn Hùng', N'admin@hl2t.edu.vn',   N'0901000001', N'Hà Nội', 1),
 (N'thuthu',  N'SEED:ThuThu@123', N'Trần Thu Hà',     N'thuthu@hl2t.edu.vn',  N'0901000002', N'Hà Nội', 2),
 (N'docgia',  N'SEED:DocGia@123', N'Nguyễn Minh Anh', N'docgia@hl2t.edu.vn',  N'0901000003', N'Hà Nội', 3),
 (N'docgia2', N'SEED:DocGia@123', N'Lê Quang Huy',    N'docgia2@hl2t.edu.vn', N'0901000004', N'Hà Nội', 3);

INSERT INTO dbo.DanhMucSach (TenDanhMuc, MoTa) VALUES
 (N'Công nghệ thông tin', N'Lập trình, cơ sở dữ liệu, mạng máy tính'),
 (N'Kinh tế',             N'Kinh tế học, quản trị kinh doanh'),
 (N'Kỹ năng sống',        N'Kỹ năng mềm, phát triển bản thân'),
 (N'Ngoại ngữ',           N'Tiếng Anh, tiếng Nhật, tiếng Hàn'),
 (N'Lịch sử',             N'Lịch sử Việt Nam và thế giới'),
 (N'Văn học',             N'Tiểu thuyết, truyện ngắn, thơ');

INSERT INTO dbo.Sach (ISBN, TenSach, TacGia, NhaXuatBan, NamXuatBan, GiaBia, TongSoLuong, SoLuongKhaDung, MaDanhMuc, MoTa) VALUES
 (N'978-604-0-00001-1', N'Lập trình C# từ cơ bản đến nâng cao', N'Phạm Công Ngô',   N'NXB Thông tin và Truyền thông', 2024, 185000, 5, 5, 1, N'Ngôn ngữ C#, lập trình hướng đối tượng, LINQ, EF Core.'),
 (N'978-604-0-00002-8', N'ASP.NET Core MVC thực chiến',         N'Nguyễn Văn Hiếu', N'NXB Bách Khoa Hà Nội',          2023, 210000, 4, 4, 1, N'Xây dựng ứng dụng web theo mô hình MVC.'),
 (N'978-604-0-00003-5', N'Cơ sở dữ liệu SQL Server',            N'Trần Minh Đức',   N'NXB Giáo dục',                   2022, 150000, 6, 6, 1, NULL),
 (N'978-604-0-00004-2', N'Phân tích và thiết kế hệ thống',      N'Lê Thị Hạnh',     N'NXB Đại học Quốc gia Hà Nội',    2021, 120000, 8, 8, 1, NULL),
 (N'978-604-0-00005-9', N'Cấu trúc dữ liệu và giải thuật',      N'Đỗ Xuân Lôi',     N'NXB Đại học Quốc gia Hà Nội',    2020, 135000, 10, 10, 1, NULL),
 (N'978-604-0-00006-6', N'Kinh tế vĩ mô căn bản',               N'Hoàng Văn Nam',   N'NXB Kinh tế Quốc dân',           2022, 99000,  3, 3, 2, NULL),
 (N'978-604-0-00007-3', N'Quản trị học đại cương',              N'Phan Thanh Bình', N'NXB Kinh tế Quốc dân',           2021, 110000, 6, 6, 2, NULL),
 (N'978-604-0-00008-0', N'Kỹ năng giao tiếp hiệu quả',          N'Vũ Thu Trang',    N'NXB Lao động',                   2023, 89000,  7, 7, 3, NULL),
 (N'978-604-0-00009-7', N'Tiếng Anh chuyên ngành CNTT',         N'Bùi Văn Tuấn',    N'NXB Giáo dục',                   2022, 95000,  9, 9, 4, NULL),
 (N'978-604-0-00010-3', N'Lịch sử Việt Nam giản yếu',           N'Nguyễn Thị Lan',  N'NXB Chính trị Quốc gia',         2019, 130000, 4, 4, 5, NULL);
GO

/* =====================================================================
   VIEW & THỦ TỤC HỖ TRỢ
   ===================================================================== */
-- Danh sách phiếu đang mượn đã quá hạn
CREATE VIEW dbo.vw_PhieuQuaHan AS
SELECT pm.MaPhieuMuon, nd.HoTen AS DocGia, pm.NgayMuon, pm.NgayHenTra,
       DATEDIFF(DAY, pm.NgayHenTra, CAST(GETDATE() AS DATE)) AS SoNgayTre
FROM dbo.PhieuMuon pm
JOIN dbo.NguoiDung nd ON nd.MaNguoiDung = pm.MaDocGia
WHERE pm.TrangThai IN (N'DangMuon', N'QuaHan') AND pm.NgayHenTra < CAST(GETDATE() AS DATE);
GO

-- Cập nhật trạng thái quá hạn và hủy phiếu chờ duyệt quá 3 ngày (QĐ7)
CREATE PROCEDURE dbo.sp_CapNhatTrangThaiPhieu
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.PhieuMuon SET TrangThai = N'QuaHan'
     WHERE TrangThai = N'DangMuon' AND NgayHenTra < CAST(GETDATE() AS DATE);

    UPDATE dbo.PhieuMuon
       SET TrangThai = N'DaHuy', GhiChu = N'Tự động hủy do quá 3 ngày chưa duyệt'
     WHERE TrangThai = N'ChoDuyet' AND NgayLap < DATEADD(DAY, -3, GETDATE());
END
GO

-- Thống kê lượt mượn theo danh mục trong khoảng thời gian
CREATE PROCEDURE dbo.sp_ThongKeTheoDanhMuc
    @TuNgay DATE,
    @DenNgay DATE
AS
BEGIN
    SET NOCOUNT ON;
    SELECT dm.TenDanhMuc, SUM(ct.SoLuong) AS SoLuotMuon
    FROM dbo.ChiTietPhieuMuon ct
    JOIN dbo.PhieuMuon pm ON pm.MaPhieuMuon = ct.MaPhieuMuon
    JOIN dbo.Sach s ON s.MaSach = ct.MaSach
    JOIN dbo.DanhMucSach dm ON dm.MaDanhMuc = s.MaDanhMuc
    WHERE pm.NgayMuon BETWEEN @TuNgay AND @DenNgay
    GROUP BY dm.TenDanhMuc
    ORDER BY SoLuotMuon DESC;
END
GO
